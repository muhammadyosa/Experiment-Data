#!/bin/bash

# Salin splashscreen.html dan splash.png ke direktori dist
echo "📄 Menyalin splashscreen.html dan splash.png ke folder dist..."
cp src-tauri/splashscreen.html dist/splashscreen.html
cp public/splash.png dist/splash.png

# Jalankan build Vite
echo "🛠️ Membuild frontend dengan Vite..."
npm run build

# Jalankan build aplikasi Tauri
echo "📦 Membuild aplikasi Tauri (portable .exe)..."
npx tauri build

echo "✅ Build selesai! Hasil ada di: src-tauri/target/release/bundle/"
